//#include <???.h> //Author by Quan dep trai
int main()
{  int x;
   long n;
   long long y=1;
scanf("%ld",&n);

for(x=1;x<=n;x++)
    y=y*x;
    printf("%lld",y);

return 0;}
