//#include <???.h> //Author by Quan dep trai
int main()
{ int n,tich,m;
   scanf("%d",&n);
   
   for( m=1;m<=10;m++)
      {int boss =n*m;
      printf("%d ",boss);}

return 0;}
