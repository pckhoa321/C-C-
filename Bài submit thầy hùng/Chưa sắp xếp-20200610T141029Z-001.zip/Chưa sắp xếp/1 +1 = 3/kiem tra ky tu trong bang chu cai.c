//#include <???.h> //Author by Quan dep trai
int main()
  {   char b;
int a=getchar();
  scanf("%d",&a);
  if (a==getchar)
  printf("%d",1);
  else printf("%d",0);



return 0;}
