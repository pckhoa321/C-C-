#include <stdio.h>

int main()
{  int a,b,c;
    scanf ("%d %d %d",&a,&b,&c);
     if(a+b+c==180 && a >0 && b>0 && c>0)
     printf("%d",1);
     else printf("%d",0);	
	
	return 0;}
