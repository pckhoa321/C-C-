//#include <???.h> //Author by Quan dep trai
 #include <conio.h> 

main(int argc, char *argv['Lan']) 
{ 
  if (argc !=1) 
     printf("Phai nhap Ten"); 
	else 
	   printf("Chao ban %s\n",argv[1]); 
	   getch();
	
}

