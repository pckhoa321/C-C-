//#include <???.h> //Author by Quan dep trai
int main()
{  int i,j,re=0,m,n;
   scanf("%d %d",&m,&n);
   for (i=1;i<=m;i++){
   	for (j=1;j<=n;j++){
   		re++;
   		if(i>1) { re=re+1;

		           printf("%d",re);}
   	       printf("%d",re);
	   }
 printf("\n");  }
return 0;}
