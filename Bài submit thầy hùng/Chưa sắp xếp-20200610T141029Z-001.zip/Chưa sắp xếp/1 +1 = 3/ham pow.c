//#include <???.h> //Author by Quan dep trai
#include<math.h>
int main()
   {
  int x,y,c;
  scanf("%d %d",&x,&y);
  c= pow(x,y);
  printf("%d",c);
  

return 0;}
