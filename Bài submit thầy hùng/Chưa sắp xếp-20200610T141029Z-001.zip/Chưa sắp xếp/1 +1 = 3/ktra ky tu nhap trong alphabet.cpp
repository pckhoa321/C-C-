/*Vi?t chuong tr�nh C cho ph�p ngu?i d�ng nh?p v�o m?t k� t? v� ki?m tra xem k� t? d� c� n?m trong b?ng ch? c�i hay kh�ng.
N?u d�ng in ra 1, sai in ra 0.
INPUT
a
OUTPUT
1 */

//#include <???.h> //Author by Quan dep trai
int main()
{
	char kytu[10];
	scanf("%s",kytu);
  
	if(kytu)
  printf("1");
  else printf("000");
	return 0;
}
