//#include <???.h> //Author by Quan dep trai
int main()
{ char telower;
  char key;
  key=20;
  for(key='A';key<='Z';key++){
     printf("%c ",key);
      putchar(telower(key));
  }
  
	printf("\n");
	printf("%c ",key);
	
  
	
	  
	
//	for(Key='a';Key<='z';Key++)
//    printf("%c ",Key);
    
	return 0;
}
