//#include <???.h> //Author by Quan dep trai
#define max 100

int main ()

{
	int n =0, a[max]; //sizeof (a) = 400
	scanf ("%d",&n);
	
	for(int i=0; i<n ; i++) //nhap cac phan tu
	   scanf ("%d",&a[i]);	
	
	for (int i =0; i<n; i++)
	    scanf ("%d",&a[i]);
	    
	    
	    
	    
	//2
	for (int i=0; i<n ; i++) //Xuat n phan tu    
	    printf ("%d",a[i]);
	    
	return 0;
}



// Luu y 
// + Ten ham chua dia chi cua phan tu dau tien nam trong mang


// Cach 2: Truyen tham chieu (ONly C++)
