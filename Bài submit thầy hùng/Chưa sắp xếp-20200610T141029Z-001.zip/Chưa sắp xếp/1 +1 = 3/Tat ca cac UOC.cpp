//#include <???.h> //Author by Quan dep trai
int main()
{ int a,b;
 scanf("%d",&a);
 for(b=1;b<=a;b++)
 {
 if(a%b==0)
 printf("%d ",b);}
return 0;}
