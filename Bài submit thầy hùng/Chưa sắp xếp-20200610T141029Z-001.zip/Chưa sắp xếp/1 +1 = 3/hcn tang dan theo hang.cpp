//#include <???.h> //Author by Quan dep trai
int main()
{   int i,j,dem=0,n,m;
scanf("%d %d",&n,&m);
   for(i=1;i<=n;i++)
  {for(j=1;j<=m;j++){
   dem++;
printf("%d",dem);}
printf("\n");}
return 0;
}
