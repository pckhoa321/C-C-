//#include <???.h> //Author by Quan dep trai
int main()
{    int a,n;
     scanf("%d",&n);
     while(n>0){
         a=n%10;
         n=n/10;
         if(n==6,0,8)
           printf("%d",1);
         else printf("%d",0);}  
return 0;}
