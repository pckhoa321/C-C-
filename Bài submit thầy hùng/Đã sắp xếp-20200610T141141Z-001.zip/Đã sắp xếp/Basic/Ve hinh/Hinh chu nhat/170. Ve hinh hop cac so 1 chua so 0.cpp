//#include <???.h> //Author by Quan dep trai

void out(int x[][20],int n,int m=0){
	if(m == 0)
		m = n;
	for(int i=0 ; i<n ; i++){	
		for(int j=0 ; j<m ; j++){
			if(i==0 || i==n-1 || j==0 || j==m-1)
				printf("%d",1);
			else printf("%d",0);		
		}	
		printf("\n");
	}
}


int main(){
	int x[20][20],n,m;
	scanf("%d",&n);
	scanf("%d",&m);
	out(x,n,m);
	
	return 0;
}
